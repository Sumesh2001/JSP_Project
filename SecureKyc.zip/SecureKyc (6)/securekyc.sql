-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2023 at 08:50 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `securekyc`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_acc`
--

CREATE TABLE `bank_acc` (
  `baid` int(11) NOT NULL,
  `account_no` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `kyc_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bank_acc`
--

INSERT INTO `bank_acc` (`baid`, `account_no`, `user_name`, `mobile`, `email`, `address`, `kyc_id`) VALUES
(1, '434267', '5', 9404688826, 'ak@gmail.com', 'Nashik', 'tt'),
(2, '915115', '10', 940468823, 'sumesh8793s@gmail.com', 'Nashik', 'tt'),
(3, '902677', '11', 7770000665, 'tanishqwalzade77@gmail.com', 'Nashik', 'tt'),
(4, '579406', '12', 9112309156, 'sumeshfake1@gmail.com', 'eq', 'tt'),
(5, '515553', '12', 3565765, 'sumesh8793s@gmail.com', 'eqdfsdfh', 'tt'),
(6, '402117', '12', 3565765, 'sumesh8793s@gmail.com', 'eqdfsdfh', 'tt'),
(9, '809144', '17', 123456789, 'naikashwini6551@gmail.com', 'wedwa', 'tt'),
(10, '899293', '20', 7490, 'sumesh8793s@gmail.com', 'nashik', 'tt'),
(11, '636025', '20', 7490, 'sumesh8793s@gmail.com', 'nashik', 'tt'),
(12, '499525', '20', 7490, 'sumesh8793s@gmail.com', 'nashik', 'tt'),
(13, '636223', '20', 7490, 'sumesh8793s@gmail.com', 'nashik', 'tt'),
(14, '856087', '21', 987654321, 'aishwaryasutare@gmail.com', 'nashik', 'tt'),
(15, '518137', '21', 987654321, 'aishwaryasutare@gmail.com', 'nashik', 'tt'),
(16, '610741', '23', 8999425876, 'naikaishwini6551@gmail.com', 'nashik', 'tt'),
(17, '722604', '23', 987654321, 'naikaishwini6551@gmail.com', 'nashik', 'tt'),
(18, '793109', '23', 987654321, 'naikaishwini6551@gmail.com', 'nashik', 'tt');

-- --------------------------------------------------------

--
-- Table structure for table `bank_tbl`
--

CREATE TABLE `bank_tbl` (
  `bid` int(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bank_tbl`
--

INSERT INTO `bank_tbl` (`bid`, `bname`, `uname`, `pass`) VALUES
(1, 'sbi', 'sbi001', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `fund_transfer`
--

CREATE TABLE `fund_transfer` (
  `fid` int(11) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_no` bigint(20) NOT NULL,
  `ifsc` varchar(100) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `senderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `fund_transfer`
--

INSERT INTO `fund_transfer` (`fid`, `account_name`, `account_no`, `ifsc`, `amount`, `senderid`) VALUES
(1, 'Sidd', 9876543210, 'SBIN0007896', 500, NULL),
(2, 'Akshay', 987653410, 'SBIN0007896', 50000, NULL),
(3, 'ganesh', 123456, 'SBIN0007896', 5000, NULL),
(4, 'Ganesh', 1234567, 'SBIN0007896', 5000, NULL),
(5, 'Varad', 98765342, 'SBIN0007896', 6000, NULL),
(6, 'sumesh', 123456, 'jqwdgiqg', 10000, NULL),
(7, 'sumesh', 12376787, 'qfdq', 1000000000, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kyc_details`
--

CREATE TABLE `kyc_details` (
  `kid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pan_number` varchar(50) NOT NULL,
  `adhar_number` bigint(50) NOT NULL,
  `panfile` text NOT NULL,
  `adharfile` text NOT NULL,
  `unique_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kyc_details`
--

INSERT INTO `kyc_details` (`kid`, `uid`, `pan_number`, `adhar_number`, `panfile`, `adharfile`, `unique_id`) VALUES
(1, 123465, '123465', 456789, 'background.jpg', 'abtus.jpg', '123465'),
(2, 3, '987654321', 123000, 'download.png', 'Invoice_Global Industrial Cleaning Equipment Market Report 2021.pdf', '8a9bcf1e51e812d0af8465a8dbcc9f741064bf0af3b3d08e6b0246437c19f7fb'),
(3, 4, '9876543', 123456, 'download.png', 'logo.jpg', '3deaa5418cef4f488068cc6011a802b2b37cadd3afce80674778c25e21f2fb1c'),
(4, 5, '126', 123, 'abtus.jpg', 'background.jpg', '65a699905c02619370bcf9207f5a477c3d67130ca71ec6f750e07fe8d510b084'),
(5, 6, '12345K', 123412341234, 'abtus.jpg', 'background.jpg', '32b239b89462f039e91f99db3e2ec13c16ed50c85f111c96968927364d8e2e13'),
(6, 3, '987654123', 1234567, 'college.jpg', 'abtus.jpg', '8e0ca26e8edad7a45832860e0f8ef3c221fba9f9bc1816812899d993ba48495a'),
(7, 3, '234562345', 1234562, 'Custom-dev-pic.jpg', 'download.png', 'f09545d0c2f906772b8c9c16a1c711554c1486087619819a7d547ce193d5f1c2'),
(8, 9, '6987452', 56130, 'test.png', 'test2.png', '5768e8b68321f60aef3903b15d261c0439c4cd72f69d386a4205e0aa40523927'),
(9, 10, '789456', 94000, 'abtus.jpg', 'background.jpg', 'e54fc6b51915e222ba6196747a19ebb8dfa651fd2b46a385a0ded647fbfefda0'),
(10, 11, '987555', 321000, 'background.jpg', 'college.jpg', '5082bfac080b44ff4ab1a45b455aed2f5aa11c5590d74ada3bb2d55bcf28cc07'),
(11, 12, 'K12345678', 123412341234, 'sample aadhar.jpg', 'sample pan.jpg', '4fa9f2875c7ed5bd9e8b625772b9d0023195eb3dc1d63a010b215ab3a3f26d3a'),
(12, 16, 'K12345689', 123412341235, 'sample aadhar.jpg', 'sample pan.jpg', 'cae7545c568a32e193dabdd3285e05dba730d643af76a735dbffc30ddaef388b'),
(13, 17, 'K12345699', 123412341255, 'sample aadhar.jpg', 'sample pan.jpg', 'c4613e026ca7f753e14f5e2e1cabc510321cbb270fcaba196462eb54013ee338'),
(14, 18, 'kk1122', 7499079487, 'sample aadhar.jpg', 'sample pan.jpg', '9f5c0d001be46c50b0a32f389e7c8cfb8d54d05254452354cc41da0f986e1b5a'),
(15, 20, 's1122', 7490, 'sample aadhar.jpg', 'sample pan.jpg', '1256486e37b27b2be9cc9b676b77e2be9fdcd61a4d882da532766d3bc0b3c28c'),
(16, 21, 'KK112233', 4321432143214321, 'sample aadhar.jpg', 'sample pan.jpg', '3b1e437c2e1168249cf01e34f42804f4779a9dba6ae55eddc258a914cead398d'),
(17, 23, 'KK112244', 224422442244, 'sample aadhar.jpg', 'sample pan.jpg', 'a793ba17fbd2db2cf2cced577918db71e7644767eb8ad8da3ede1d5c35fefdcf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `password` text NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `mobile`, `password`, `email`) VALUES
(1, 'siddharth', 'mandwadwe', 9404688826, '123', 'siddharthraje1988@gmail.com'),
(3, 'Sahil', 'Mandwade', 9876543210, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'sidd@gmail.com'),
(4, 'Ganesh', 'Patil', 940468825, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'ganesh@gmail.com'),
(5, 'Akshay', 'khairnar', 8999910460, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'hsyfhy@gmail.com'),
(6, 'Demo', 'd', 1234567890, '2a97516c354b68848cdbd8f54a226a0a55b21ed138e207ad6c5cbb9c00aa5aea', 'demo@gmail.co'),
(7, 'Shravni', 'Lokhande', 9876543210, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'shravni@gmail.com'),
(8, 'varad', 'joshi', 9876543210, '22a2fa7d04248931a8853a7714b86546610afd01b2b1841890e979ba7ba6bcae', 'varad@gmail.com'),
(9, 'ganesh', 'patil', 9404688899, '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 'ganesh@gmail.com'),
(10, 'Sumesh', 'Shaji', 940468823, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'sumesh8793s@gmail.com'),
(11, 'Tanish', 'Walzade', 7770000665, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'tanishqwalzade77@gmail.com'),
(12, 'sumeshs', ' haji', 9112309156, '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 'sumeshfake1@gmail.com'),
(13, 's', 's', 911, '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 's@mail.com'),
(14, 'su', 'su', 123456, '4288253383796947c37bfb9f2b9a66c6f9e35cbbfd0e0605c48978c84316461b', 's@mail.com'),
(15, 'ss', 'ss', 1234567, '8bb0cf6eb9b17d0f7d22b456f121257dc1254e1f01665370476383ea776df414', 'ss@mail.com'),
(16, 'Aishwraya', 'sutare', 4390958587, '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 'aishwaryasutare@gmail.com'),
(17, 'Ashwini', 'Naik', 8999425875, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'naikashwini6551@gmail.com'),
(18, 'Sumeshs', 'Shaji', 7499079487, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'sumesh1802@gmail.com'),
(19, 'Sumeshs', 'Shaji', 7499079487, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'sumesh1802@gmail.com'),
(20, 'sample', 'ss', 74990, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'sumesh8793s@gmail.com'),
(21, 'aishwarya', 'sutare', 987654321, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'aishwaryasutare@gmail.com'),
(22, 'aishwarya', 'sutare', 987654321, '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'aishwaryasutare@gmail.com'),
(23, 'pokemon', 'naik', 8999425876, 'fe2592b42a727e977f055947385b709cc82b16b9a87f88c6abf3900d65d0cdc3', 'naikaishwini6551@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_acc`
--
ALTER TABLE `bank_acc`
  ADD PRIMARY KEY (`baid`);

--
-- Indexes for table `bank_tbl`
--
ALTER TABLE `bank_tbl`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `fund_transfer`
--
ALTER TABLE `fund_transfer`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `kyc_details`
--
ALTER TABLE `kyc_details`
  ADD PRIMARY KEY (`kid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_acc`
--
ALTER TABLE `bank_acc`
  MODIFY `baid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `bank_tbl`
--
ALTER TABLE `bank_tbl`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fund_transfer`
--
ALTER TABLE `fund_transfer`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kyc_details`
--
ALTER TABLE `kyc_details`
  MODIFY `kid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
